Decorations

Objects in this path are used to decorate scenery. They include items like:

Gates
Movable Fences
Traffic Cones
Boxes
