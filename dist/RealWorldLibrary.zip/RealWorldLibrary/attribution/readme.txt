Add text files into this path to provide credit and attribution to the authors of the Works contained within this library.
