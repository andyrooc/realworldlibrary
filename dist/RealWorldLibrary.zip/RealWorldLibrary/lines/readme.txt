# Lines

If possible, include color and width in file name, e.g.:

yellow_taxi_1f.lin
