Welcome to the [Library Name]
Developer: [Developer Name]

This library is compiled in accordance to the Real World Library 1.0 structure standard.
